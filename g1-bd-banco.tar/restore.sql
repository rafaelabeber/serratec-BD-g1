--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2
-- Dumped by pg_dump version 16.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "serratec-bd-grupo1";
--
-- Name: serratec-bd-grupo1; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "serratec-bd-grupo1" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE "serratec-bd-grupo1" OWNER TO postgres;

\connect -reuse-previous=on "dbname='serratec-bd-grupo1'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: categoria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categoria (
    cat_cd_id integer NOT NULL,
    cat_tx_nome character varying(20) NOT NULL,
    cat_tx_descricao character varying(200)
);


ALTER TABLE public.categoria OWNER TO postgres;

--
-- Name: categoria_cat_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categoria_cat_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categoria_cat_cd_id_seq OWNER TO postgres;

--
-- Name: categoria_cat_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categoria_cat_cd_id_seq OWNED BY public.categoria.cat_cd_id;


--
-- Name: cliente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cliente (
    cli_cd_id integer NOT NULL,
    cli_tx_nome character varying(50) NOT NULL,
    cli_tx_telefone character varying(16) NOT NULL,
    cli_tx_nome_usuario character varying(20) NOT NULL,
    cli_tx_cpf character varying(14) NOT NULL,
    cli_tx_email character varying(50) NOT NULL,
    cli_dt_nascimento date NOT NULL,
    cli_fk_end integer NOT NULL
);


ALTER TABLE public.cliente OWNER TO postgres;

--
-- Name: cliente_cli_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cliente_cli_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cliente_cli_cd_id_seq OWNER TO postgres;

--
-- Name: cliente_cli_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cliente_cli_cd_id_seq OWNED BY public.cliente.cli_cd_id;


--
-- Name: endereco; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.endereco (
    end_cd_id integer NOT NULL,
    end_tx_cidade character varying(25),
    end_tx_uf character varying(2),
    end_tx_cep character varying(9),
    end_tx_numero character varying(5)
);


ALTER TABLE public.endereco OWNER TO postgres;

--
-- Name: endereco_end_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.endereco_end_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.endereco_end_cd_id_seq OWNER TO postgres;

--
-- Name: endereco_end_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.endereco_end_cd_id_seq OWNED BY public.endereco.end_cd_id;


--
-- Name: funcionario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.funcionario (
    fun_cd_id integer NOT NULL,
    fun_tx_nome character varying(50) NOT NULL,
    fun_tx_cpf character varying(14) NOT NULL,
    fun_tx_funcao character varying(20) NOT NULL,
    fun_int_idade integer
);


ALTER TABLE public.funcionario OWNER TO postgres;

--
-- Name: funcionario_fun_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.funcionario_fun_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.funcionario_fun_cd_id_seq OWNER TO postgres;

--
-- Name: funcionario_fun_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.funcionario_fun_cd_id_seq OWNED BY public.funcionario.fun_cd_id;


--
-- Name: pedido; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pedido (
    ped_cd_id integer NOT NULL,
    ped_fl_valor_total double precision NOT NULL,
    ped_dt_pedido timestamp without time zone NOT NULL,
    ped_dt_previsao_entrega date NOT NULL,
    ped_tx_transporte character varying(30) NOT NULL,
    ped_fk_cli integer NOT NULL
);


ALTER TABLE public.pedido OWNER TO postgres;

--
-- Name: nota_fiscal; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.nota_fiscal AS
 SELECT c.cli_tx_nome AS nomecliente,
    c.cli_tx_cpf AS cpfciente,
    (((((((e.end_tx_cidade)::text || ', '::text) || (e.end_tx_uf)::text) || ', '::text) || (e.end_tx_cep)::text) || ', '::text) || (e.end_tx_numero)::text) AS enderecocliente,
    p.ped_fl_valor_total AS valortotal,
    p.ped_dt_pedido AS datapedido,
    p.ped_cd_id AS idpedido
   FROM ((public.cliente c
     JOIN public.endereco e ON ((c.cli_fk_end = e.end_cd_id)))
     JOIN public.pedido p ON ((c.cli_cd_id = p.ped_fk_cli)));


ALTER VIEW public.nota_fiscal OWNER TO postgres;

--
-- Name: pedido_ped_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pedido_ped_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pedido_ped_cd_id_seq OWNER TO postgres;

--
-- Name: pedido_ped_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pedido_ped_cd_id_seq OWNED BY public.pedido.ped_cd_id;


--
-- Name: pedido_produto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pedido_produto (
    pedprod_fk_ped integer NOT NULL,
    pedprod_fk_prod integer NOT NULL
);


ALTER TABLE public.pedido_produto OWNER TO postgres;

--
-- Name: produto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.produto (
    prod_cd_id integer NOT NULL,
    prod_tx_nome character varying(50) NOT NULL,
    prod_tx_descricao character varying(200) NOT NULL,
    prod_dt_fabricacao date NOT NULL,
    prod_int_estoque bigint NOT NULL,
    prod_fl_valor_unitario double precision NOT NULL,
    prod_fk_fun integer NOT NULL,
    prod_fk_cat integer NOT NULL
);


ALTER TABLE public.produto OWNER TO postgres;

--
-- Name: produto_prod_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.produto_prod_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.produto_prod_cd_id_seq OWNER TO postgres;

--
-- Name: produto_prod_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.produto_prod_cd_id_seq OWNED BY public.produto.prod_cd_id;


--
-- Name: categoria cat_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria ALTER COLUMN cat_cd_id SET DEFAULT nextval('public.categoria_cat_cd_id_seq'::regclass);


--
-- Name: cliente cli_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente ALTER COLUMN cli_cd_id SET DEFAULT nextval('public.cliente_cli_cd_id_seq'::regclass);


--
-- Name: endereco end_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endereco ALTER COLUMN end_cd_id SET DEFAULT nextval('public.endereco_end_cd_id_seq'::regclass);


--
-- Name: funcionario fun_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.funcionario ALTER COLUMN fun_cd_id SET DEFAULT nextval('public.funcionario_fun_cd_id_seq'::regclass);


--
-- Name: pedido ped_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido ALTER COLUMN ped_cd_id SET DEFAULT nextval('public.pedido_ped_cd_id_seq'::regclass);


--
-- Name: produto prod_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto ALTER COLUMN prod_cd_id SET DEFAULT nextval('public.produto_prod_cd_id_seq'::regclass);


--
-- Data for Name: categoria; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categoria (cat_cd_id, cat_tx_nome, cat_tx_descricao) FROM stdin;
\.
COPY public.categoria (cat_cd_id, cat_tx_nome, cat_tx_descricao) FROM '$$PATH$$/3651.dat';

--
-- Data for Name: cliente; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cliente (cli_cd_id, cli_tx_nome, cli_tx_telefone, cli_tx_nome_usuario, cli_tx_cpf, cli_tx_email, cli_dt_nascimento, cli_fk_end) FROM stdin;
\.
COPY public.cliente (cli_cd_id, cli_tx_nome, cli_tx_telefone, cli_tx_nome_usuario, cli_tx_cpf, cli_tx_email, cli_dt_nascimento, cli_fk_end) FROM '$$PATH$$/3649.dat';

--
-- Data for Name: endereco; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.endereco (end_cd_id, end_tx_cidade, end_tx_uf, end_tx_cep, end_tx_numero) FROM stdin;
\.
COPY public.endereco (end_cd_id, end_tx_cidade, end_tx_uf, end_tx_cep, end_tx_numero) FROM '$$PATH$$/3647.dat';

--
-- Data for Name: funcionario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.funcionario (fun_cd_id, fun_tx_nome, fun_tx_cpf, fun_tx_funcao, fun_int_idade) FROM stdin;
\.
COPY public.funcionario (fun_cd_id, fun_tx_nome, fun_tx_cpf, fun_tx_funcao, fun_int_idade) FROM '$$PATH$$/3653.dat';

--
-- Data for Name: pedido; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pedido (ped_cd_id, ped_fl_valor_total, ped_dt_pedido, ped_dt_previsao_entrega, ped_tx_transporte, ped_fk_cli) FROM stdin;
\.
COPY public.pedido (ped_cd_id, ped_fl_valor_total, ped_dt_pedido, ped_dt_previsao_entrega, ped_tx_transporte, ped_fk_cli) FROM '$$PATH$$/3657.dat';

--
-- Data for Name: pedido_produto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pedido_produto (pedprod_fk_ped, pedprod_fk_prod) FROM stdin;
\.
COPY public.pedido_produto (pedprod_fk_ped, pedprod_fk_prod) FROM '$$PATH$$/3658.dat';

--
-- Data for Name: produto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.produto (prod_cd_id, prod_tx_nome, prod_tx_descricao, prod_dt_fabricacao, prod_int_estoque, prod_fl_valor_unitario, prod_fk_fun, prod_fk_cat) FROM stdin;
\.
COPY public.produto (prod_cd_id, prod_tx_nome, prod_tx_descricao, prod_dt_fabricacao, prod_int_estoque, prod_fl_valor_unitario, prod_fk_fun, prod_fk_cat) FROM '$$PATH$$/3655.dat';

--
-- Name: categoria_cat_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categoria_cat_cd_id_seq', 5, true);


--
-- Name: cliente_cli_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cliente_cli_cd_id_seq', 5, true);


--
-- Name: endereco_end_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.endereco_end_cd_id_seq', 5, true);


--
-- Name: funcionario_fun_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.funcionario_fun_cd_id_seq', 5, true);


--
-- Name: pedido_ped_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pedido_ped_cd_id_seq', 5, true);


--
-- Name: produto_prod_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.produto_prod_cd_id_seq', 5, true);


--
-- Name: categoria categoria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria
    ADD CONSTRAINT categoria_pkey PRIMARY KEY (cat_cd_id);


--
-- Name: cliente cliente_cli_tx_cpf_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_cli_tx_cpf_key UNIQUE (cli_tx_cpf);


--
-- Name: cliente cliente_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_pkey PRIMARY KEY (cli_cd_id);


--
-- Name: endereco endereco_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endereco
    ADD CONSTRAINT endereco_pkey PRIMARY KEY (end_cd_id);


--
-- Name: funcionario funcionario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.funcionario
    ADD CONSTRAINT funcionario_pkey PRIMARY KEY (fun_cd_id);


--
-- Name: pedido pedido_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido
    ADD CONSTRAINT pedido_pkey PRIMARY KEY (ped_cd_id);


--
-- Name: produto produto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_pkey PRIMARY KEY (prod_cd_id);


--
-- Name: cliente cliente_cli_fk_end_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_cli_fk_end_fkey FOREIGN KEY (cli_fk_end) REFERENCES public.endereco(end_cd_id);


--
-- Name: pedido pedido_ped_fk_cli_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido
    ADD CONSTRAINT pedido_ped_fk_cli_fkey FOREIGN KEY (ped_fk_cli) REFERENCES public.cliente(cli_cd_id);


--
-- Name: pedido_produto pedido_produto_pedprod_fk_ped_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_produto
    ADD CONSTRAINT pedido_produto_pedprod_fk_ped_fkey FOREIGN KEY (pedprod_fk_ped) REFERENCES public.pedido(ped_cd_id);


--
-- Name: pedido_produto pedido_produto_pedprod_fk_prod_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_produto
    ADD CONSTRAINT pedido_produto_pedprod_fk_prod_fkey FOREIGN KEY (pedprod_fk_prod) REFERENCES public.produto(prod_cd_id);


--
-- Name: produto produto_prod_fk_cat_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_prod_fk_cat_fkey FOREIGN KEY (prod_fk_cat) REFERENCES public.categoria(cat_cd_id);


--
-- Name: produto produto_prod_fk_fun_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_prod_fk_fun_fkey FOREIGN KEY (prod_fk_fun) REFERENCES public.funcionario(fun_cd_id);


--
-- PostgreSQL database dump complete
--

